import os
import subprocess
import platform
from typing import Optional
from rich.console import Console
from rich.prompt import Prompt, IntPrompt, Confirm
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.layout import Layout
from rich import box
from ..services.presentation_service import PresentationService
from ..localization.manager import get_localization_manager


class CLIInterface:
    def __init__(self):
        self.console = Console()
        self.service = PresentationService()
        self.loc = get_localization_manager()
        
    def show_header(self):
        header_text = Text()
        header_text.append(self.loc.t("app_title"), style="bold cyan")
        
        header_panel = Panel(
            header_text,
            box=box.DOUBLE,
            style="bold cyan",
            padding=(1, 2)
        )
        self.console.print(header_panel)
        self.console.print()
    
    def show_menu(self):
        menu_table = Table(show_header=False, box=box.SIMPLE, padding=(0, 2))
        menu_table.add_column(self.loc.t("option_column"), style="bold cyan", width=3)
        menu_table.add_column(self.loc.t("description_column"), style="white")
        
        menu_table.add_row("1", self.loc.t("menu_create"))
        menu_table.add_row("2", self.loc.t("menu_show"))
        menu_table.add_row("3", self.loc.t("menu_correct"))
        menu_table.add_row("4", self.loc.t("menu_delete"))
        menu_table.add_row("5", self.loc.t("menu_language"))
        menu_table.add_row("6", self.loc.t("menu_exit"))
        
        menu_panel = Panel(
            menu_table,
            title=f"[bold white]{self.loc.t('main_menu')}[/bold white]",
            border_style="cyan",
            padding=(1, 2)
        )
        self.console.print(menu_panel)
    
    def get_presentation_details(self) -> dict:
        self.console.print(Panel(
            "[bold white]Настройка новой презентации[/bold white]",
            style="cyan"
        ))
        self.console.print()
        
        title = Prompt.ask(
            f"[bold cyan]{self.loc.t('enter_title')}[/bold cyan]",
            default=self.loc.t("default_title")
        )
        
        language_choice = Prompt.ask(
            f"[bold cyan]{self.loc.t('choose_language')}[/bold cyan]",
            choices=["русский", "english"],
            default="русский"
        )
        
        max_sections = IntPrompt.ask(
            f"[bold cyan]{self.loc.t('section_count')}[/bold cyan]",
            default=3,
            show_default=True
        )
        
        max_slides = IntPrompt.ask(
            f"[bold cyan]{self.loc.t('slide_count')}[/bold cyan]",
            default=4,
            show_default=True
        )
        
        return {
            'title': title,
            'language': language_choice,
            'max_sections': max_sections,
            'max_slides': max_slides
        }
    
    def generate_presentation_with_progress(self, **kwargs):
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40),
            TaskProgressColumn(),
            console=self.console,
            transient=False
        ) as progress:
            
            task = progress.add_task(self.loc.t("initializing"), total=1)
            
            def progress_callback(description: str, current: int, total: int):
                progress.update(task, description=description, completed=current, total=total)
            
            presentation = self.service.generate_presentation(
                progress_callback=progress_callback,
                **kwargs
            )
            
            progress.update(task, description="✅ Генерация завершена!", completed=1, total=1)
            
        return presentation
    
    def show_presentation_summary(self, presentation):
        stats = self.service.get_presentation_stats(presentation)
        
        summary_table = Table(show_header=False, box=box.SIMPLE)
        summary_table.add_column(self.loc.t("parameter_column"), style="bold cyan", width=20)
        summary_table.add_column(self.loc.t("value_column"), style="white")
        
        summary_table.add_row(self.loc.t("title"), stats['title'])
        summary_table.add_row(self.loc.t("sections"), str(stats['sections_count']))
        summary_table.add_row(self.loc.t("total_slides"), str(stats['total_slides']))
        summary_table.add_row(self.loc.t("language"), stats['language'])
        summary_table.add_row(self.loc.t("created"), stats['created_at'])
        
        summary_panel = Panel(
            summary_table,
            title=f"[bold white]{self.loc.t('presentation_info')}[/bold white]",
            border_style="green",
            padding=(1, 2)
        )
        self.console.print(summary_panel)
    
    def save_and_open_presentation(self, presentation):
        self.console.print(f"\n[bold cyan]{self.loc.t('saving')}[/bold cyan]")
        
        try:
            presentation_id = self.service.save_to_database(presentation)
            file_path = self.service.save_presentation(presentation)
            
            self.console.print(f"[bold green]{self.loc.t('saved')} {file_path}[/bold green]")
            self.console.print(f"[bold green]{self.loc.t('db_id')} {presentation_id}[/bold green]")
            
            self.console.print(f"\n[bold cyan]{self.loc.t('what_next')}[/bold cyan]")
            self.console.print(f"1. {self.loc.t('open_pres')}")
            self.console.print(f"2. {self.loc.t('correct_pres')}")
            self.console.print(f"3. {self.loc.t('skip')}")
            
            choice = Prompt.ask(
                self.loc.t("choose_option"),
                choices=["1", "2", "3"],
                default="1"
            )
            
            if choice == "1":
                self.open_file(file_path)
            elif choice == "2":
                self.correct_presentation_dialog(presentation_id, presentation.language)
                
        except Exception as e:
            self.console.print(f"[bold red]{self.loc.t('save_error')} {e}[/bold red]")
    
    def open_file(self, file_path: str):
        try:
            system = platform.system()
            if system == "Windows":
                os.startfile(file_path)
            elif system == "Darwin":
                subprocess.run(["open", file_path])
            elif system == "Linux":
                subprocess.run(["xdg-open", file_path])
            
            self.console.print(f"[bold green]{self.loc.t('opened')}[/bold green]")
        except Exception as e:
            self.console.print(f"[bold red]{self.loc.t('open_error')} {e}[/bold red]")
    
    def show_saved_presentations(self):
        presentations = self.service.list_saved_presentations()
        
        if not presentations:
            self.console.print(Panel(
                "[yellow]∅ Нет сохраненных презентаций[/yellow]",
                style="yellow"
            ))
            return
        
        table = Table(title="Сохраненные презентации", box=box.ROUNDED)
        table.add_column("№", style="cyan", width=5)
        table.add_column("■ Название файла", style="white")
        
        for i, filename in enumerate(presentations, 1):
            table.add_row(str(i), filename)
        
        self.console.print(table)
        self.console.print()
        
        if Confirm.ask("[bold cyan]► Открыть презентацию?[/bold cyan]"):
            try:
                choice = IntPrompt.ask(
                    "Введите номер презентации",
                    show_default=False
                )
                if 1 <= choice <= len(presentations):
                    filename = presentations[choice - 1]
                    file_path = os.path.join("output", filename)
                    self.open_file(file_path)
                else:
                    self.console.print("[bold red]× Неверный номер![/bold red]")
            except Exception as e:
                self.console.print(f"[bold red]× Ошибка: {e}[/bold red]")
    
    def delete_presentation(self):
        presentations = self.service.list_saved_presentations()
        
        if not presentations:
            self.console.print(Panel(
                "[yellow]∅ Нет сохраненных презентаций для удаления[/yellow]",
                style="yellow"
            ))
            return
        
        table = Table(title="Удаление презентации", box=box.ROUNDED)
        table.add_column("№", style="cyan", width=5)
        table.add_column("■ Название файла", style="white")
        
        for i, filename in enumerate(presentations, 1):
            table.add_row(str(i), filename)
        
        self.console.print(table)
        
        try:
            choice = IntPrompt.ask(
                "Введите номер презентации для удаления",
                show_default=False
            )
            
            if 1 <= choice <= len(presentations):
                filename = presentations[choice - 1]
                
                if Confirm.ask(f"[bold red]⚠ Удалить '{filename}'?[/bold red]"):
                    if self.service.delete_saved_presentation(filename):
                        self.console.print(f"[bold green]√ Презентация '{filename}' удалена![/bold green]")
                    else:
                        self.console.print(f"[bold red]× Не удалось удалить '{filename}'[/bold red]")
            else:
                self.console.print("[bold red]× Неверный номер![/bold red]")
                
        except Exception as e:
            self.console.print(f"[bold red]× Ошибка: {e}[/bold red]")
    
    def correct_presentation_dialog(self, presentation_id: int, language: str = "русский"):
        self.console.print(Panel(
            "[bold white]✎ Корректировка презентации[/bold white]",
            style="yellow"
        ))
        
        correction_prompt = Prompt.ask(
            "[bold cyan]■ Опишите, что нужно изменить в презентации[/bold cyan]"
        )
        
        progress_text = ""
        
        def progress_callback(text: str):
            nonlocal progress_text
            progress_text = text
            self.console.print(f"[bold cyan]↻ {text}[/bold cyan]")
        
        try:
            corrected_presentation = self.service.apply_correction(
                presentation_id, correction_prompt, language, progress_callback
            )
            
            if corrected_presentation:
                self.console.print("[bold green]√ Корректировка применена![/bold green]")
                
                if Confirm.ask("\n[bold cyan]⇓ Сохранить исправленную презентацию?[/bold cyan]"):
                    file_path = self.service.save_presentation(corrected_presentation)
                    self.console.print(f"[bold green]√ Презентация сохранена: {file_path}[/bold green]")
                    
                    if Confirm.ask("\n[bold cyan]► Открыть презентацию?[/bold cyan]"):
                        self.open_file(file_path)
                
                if Confirm.ask("\n[bold cyan]✎ Внести еще изменения?[/bold cyan]"):
                    self.correct_presentation_dialog(presentation_id, language)
            else:
                self.console.print("[bold red]× Не удалось применить корректировку[/bold red]")
                
        except Exception as e:
            self.console.print(f"[bold red]× Ошибка корректировки: {e}[/bold red]")
    
    def show_correction_menu(self):
        presentations = self.service.get_database_presentations()
        
        if not presentations:
            self.console.print(Panel(
                "[yellow]∅ Нет презентаций для корректировки[/yellow]",
                style="yellow"
            ))
            return
        
        table = Table(title="Презентации для корректировки", box=box.ROUNDED)
        table.add_column("ID", style="cyan", width=5)
        table.add_column("■ Название", style="white")
        table.add_column("∞ Язык", style="green", width=10)
        table.add_column("⌚ Создано", style="blue", width=15)
        
        for pres in presentations:
            created_at = pres['created_at'][:16] if pres['created_at'] else "Н/Д"
            table.add_row(
                str(pres['id']),
                pres['title'],
                pres['language'],
                created_at
            )
        
        self.console.print(table)
        self.console.print()
        
        try:
            choice = IntPrompt.ask(
                "Введите ID презентации для корректировки",
                show_default=False
            )
            
            selected_pres = next((p for p in presentations if p['id'] == choice), None)
            if selected_pres:
                self.correct_presentation_dialog(choice, selected_pres['language'])
            else:
                self.console.print("[bold red]× Презентация с таким ID не найдена![/bold red]")
                
        except Exception as e:
            self.console.print(f"[bold red]× Ошибка: {e}[/bold red]")
    
    def run(self):
        self.console.clear()
        self.show_header()
        
        try:
            while True:
                self.show_menu()
                
                choice = Prompt.ask(
                    f"\n[bold cyan]{self.loc.t('choose_option')}[/bold cyan]",
                    choices=["1", "2", "3", "4", "5", "6"],
                    show_choices=False
                )
                
                self.console.print()
                
                if choice == "1":
                    try:
                        details = self.get_presentation_details()
                        self.console.print()
                        
                        presentation = self.generate_presentation_with_progress(**details)
                        
                        self.console.print()
                        self.show_presentation_summary(presentation)
                        self.save_and_open_presentation(presentation)
                        
                    except KeyboardInterrupt:
                        self.console.print("\n[bold yellow]⚠ Генерация отменена пользователем[/bold yellow]")
                    except Exception as e:
                        self.console.print(f"\n[bold red]× Ошибка генерации: {e}[/bold red]")
                        
                elif choice == "2":
                    self.show_saved_presentations()
                    
                elif choice == "3":
                    self.show_correction_menu()
                    
                elif choice == "4":
                    self.delete_presentation()
                    
                elif choice == "5":
                    self.show_language_menu()
                    
                elif choice == "6":
                    self.console.print(Panel(
                        f"[bold white]{self.loc.t('goodbye')}[/bold white]",
                        style="cyan"
                    ))
                    break
                
                self.console.print("\n" + "─" * 50 + "\n")
                
        finally:
            self.service.cleanup_database()
    
    def show_language_menu(self):
        self.console.print(Panel(
            f"[bold white]{self.loc.t('language_settings')}[/bold white]",
            style="yellow"
        ))
        
        current_lang = self.loc.get_language()
        self.console.print(f"\n[bold cyan]{self.loc.t('current_language')} {current_lang}[/bold cyan]")
        
        languages = self.loc.get_available_languages()
        
        self.console.print(f"\n[bold cyan]{self.loc.t('choose_interface_lang')}[/bold cyan]")
        for i, lang in enumerate(languages, 1):
            self.console.print(f"{i}. {lang}")
        
        try:
            choice = IntPrompt.ask(
                self.loc.t("choose_option"),
                show_default=False
            )
            
            if 1 <= choice <= len(languages):
                new_language = languages[choice - 1]
                if self.loc.set_language(new_language):
                    self.console.print(f"[bold green]{self.loc.t('language_changed')}[/bold green]")
                    self.console.print(f"[bold yellow]{self.loc.t('restart_note')}[/bold yellow]")
                else:
                    self.console.print("[bold red]× Ошибка смены языка[/bold red]")
            else:
                self.console.print("[bold red]× Неверный номер![/bold red]")
        except Exception as e:
            self.console.print(f"[bold red]× Ошибка: {e}[/bold red]")
