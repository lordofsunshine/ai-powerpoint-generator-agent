import os
import re
from pathlib import Path
from typing import Optional, List
from pptx import Presentation as PPTXPresentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_VERTICAL_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.dml import MSO_THEME_COLOR
from ..models.presentation import Presentation
from .decorations import SlideDecorator


class PPTXGenerator:
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.decorator = SlideDecorator()
        
    def _create_title_slide(self, pptx: PPTXPresentation, presentation: Presentation, slide_index: int = 0, total_slides: int = 1) -> None:
        title_slide_layout = pptx.slide_layouts[0]
        slide = pptx.slides.add_slide(title_slide_layout)
        
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        title.text = presentation.title
        if presentation.summary:
            subtitle.text = presentation.summary
        else:
            subtitle.text = "Created with AI presentation generator"
            
        self._style_title_text(title.text_frame)
        self._style_subtitle_text(subtitle.text_frame)
        
        self.decorator.add_slide_decoration(slide, slide_index, total_slides, "title")
        self.decorator.apply_text_formatting(title.text_frame, "title")
    
    def _create_section_title_slide(self, pptx: PPTXPresentation, section_title: str, slide_index: int, total_slides: int) -> None:
        section_header_layout = pptx.slide_layouts[2]
        slide = pptx.slides.add_slide(section_header_layout)
        
        title = slide.shapes.title
        title.text = section_title
        self._style_section_title_text(title.text_frame)
        
        self.decorator.add_slide_decoration(slide, slide_index, total_slides, "section")
        self.decorator.apply_text_formatting(title.text_frame, "title")
    
    def _create_content_slide(self, pptx: PPTXPresentation, slide_title: str, slide_content: str, slide_index: int, total_slides: int) -> None:
        if self._should_use_list_format(slide_content):
            self._create_list_slide(pptx, slide_title, slide_content, slide_index, total_slides)
        elif self._should_use_two_column(slide_content):
            self._create_two_column_slide(pptx, slide_title, slide_content, slide_index, total_slides)
        else:
            self._create_enhanced_content_slide(pptx, slide_title, slide_content, slide_index, total_slides)
    
    def _should_use_list_format(self, content: str) -> bool:
        list_indicators = ['•', '-', '1.', '2.', '3.', 'первый', 'второй', 'третий', 'этапы:', 'шаги:', 'принципы:']
        return any(indicator in content.lower() for indicator in list_indicators)
    
    def _should_use_two_column(self, content: str) -> bool:
        return len(content) > 200 and ('преимущества' in content.lower() or 'недостатки' in content.lower() or 'плюсы' in content.lower())
    
    def _create_list_slide(self, pptx: PPTXPresentation, slide_title: str, slide_content: str, slide_index: int, total_slides: int) -> None:
        blank_layout = pptx.slide_layouts[6]
        slide = pptx.slides.add_slide(blank_layout)
        
        title_left = Inches(0.5)
        title_top = Inches(0.5)
        title_width = Inches(9)
        title_height = Inches(1)
        title_box = slide.shapes.add_textbox(title_left, title_top, title_width, title_height)
        title_frame = title_box.text_frame
        title_frame.text = slide_title
        self._style_slide_title_text(title_frame)
        
        list_items = self._extract_list_items(slide_content)
        
        left = Inches(1)
        top = Inches(2)
        width = Inches(8)
        height = Inches(5)
        text_box = slide.shapes.add_textbox(left, top, width, height)
        text_frame = text_box.text_frame
        
        for i, item in enumerate(list_items):
            if i == 0:
                p = text_frame.paragraphs[0]
            else:
                p = text_frame.add_paragraph()
            p.text = f"• {item.strip()}"
            p.level = 0
            self._style_list_text(p)
        
        self.decorator.add_slide_decoration(slide, slide_index, total_slides, "list")
        self.decorator.apply_text_formatting(text_frame, "list")
    
    def _create_two_column_slide(self, pptx: PPTXPresentation, slide_title: str, slide_content: str, slide_index: int, total_slides: int) -> None:
        blank_layout = pptx.slide_layouts[6]
        slide = pptx.slides.add_slide(blank_layout)
        
        title_left = Inches(0.5)
        title_top = Inches(0.5)
        title_width = Inches(9)
        title_height = Inches(1)
        title_box = slide.shapes.add_textbox(title_left, title_top, title_width, title_height)
        title_frame = title_box.text_frame
        title_frame.text = slide_title
        self._style_slide_title_text(title_frame)
        
        parts = slide_content.split('.', 1)
        left_content = parts[0] if len(parts) > 0 else slide_content[:len(slide_content)//2]
        right_content = parts[1] if len(parts) > 1 else slide_content[len(slide_content)//2:]
        
        left_col = slide.shapes.add_textbox(Inches(0.5), Inches(2), Inches(4), Inches(5))
        left_frame = left_col.text_frame
        left_frame.text = left_content.strip()
        self._style_content_text(left_frame)
        
        right_col = slide.shapes.add_textbox(Inches(5), Inches(2), Inches(4), Inches(5))
        right_frame = right_col.text_frame
        right_frame.text = right_content.strip()
        self._style_content_text(right_frame)
        
        separator = slide.shapes.add_connector(1, Inches(4.7), Inches(1.8), Inches(4.7), Inches(6.2))
        separator.line.color.rgb = RGBColor(200, 200, 200)
        
        self.decorator.add_slide_decoration(slide, slide_index, total_slides, "content")
        self.decorator.apply_text_formatting(left_frame, "content")
        self.decorator.apply_text_formatting(right_frame, "content")
    
    def _create_enhanced_content_slide(self, pptx: PPTXPresentation, slide_title: str, slide_content: str, slide_index: int, total_slides: int) -> None:
        blank_layout = pptx.slide_layouts[6]
        slide = pptx.slides.add_slide(blank_layout)
        
        title_left = Inches(0.5)
        title_top = Inches(0.3)
        title_width = Inches(9)
        title_height = Inches(1.2)
        title_box = slide.shapes.add_textbox(title_left, title_top, title_width, title_height)
        title_frame = title_box.text_frame
        title_frame.text = slide_title
        self._style_slide_title_text(title_frame)
        
        content_shape = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(0.5), Inches(1.8),
            Inches(9), Inches(5.5)
        )
        fill = content_shape.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(248, 249, 250)
        line = content_shape.line
        line.color.rgb = RGBColor(233, 236, 239)
        
        content_frame = content_shape.text_frame
        content_frame.margin_left = Inches(0.3)
        content_frame.margin_right = Inches(0.3)
        content_frame.margin_top = Inches(0.3)
        content_frame.margin_bottom = Inches(0.3)
        content_frame.vertical_anchor = MSO_VERTICAL_ANCHOR.TOP
        content_frame.text = slide_content
        self._style_enhanced_content_text(content_frame)
        
        self.decorator.add_slide_decoration(slide, slide_index, total_slides, "content")
        self.decorator.apply_text_formatting(content_frame, "content")
    
    def _extract_list_items(self, content: str) -> List[str]:
        lines = content.split('\n')
        items = []
        current_item = ""
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith(('•', '-', '1.', '2.', '3.', '4.', '5.')):
                if current_item:
                    items.append(current_item)
                current_item = re.sub(r'^[•\-\d\.]\s*', '', line)
            else:
                if current_item:
                    current_item += f" {line}"
                else:
                    current_item = line
        
        if current_item:
            items.append(current_item)
        
        if not items:
            sentences = content.split('.')
            items = [s.strip() for s in sentences if s.strip()][:5]
        
        return items
    
    def _style_title_text(self, text_frame) -> None:
        text_frame.word_wrap = True
        text_frame.auto_size = None
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0] if p.runs else p.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(44)
        font.bold = True
        font.color.rgb = RGBColor(68, 114, 196)
    
    def _style_subtitle_text(self, text_frame) -> None:
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0] if p.runs else p.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(20)
        font.color.rgb = RGBColor(89, 89, 89)
    
    def _style_section_title_text(self, text_frame) -> None:
        text_frame.word_wrap = True
        text_frame.auto_size = None
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0] if p.runs else p.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(36)
        font.bold = True
        font.color.rgb = RGBColor(68, 114, 196)
    
    def _style_slide_title_text(self, text_frame) -> None:
        text_frame.word_wrap = True
        text_frame.auto_size = None
        p = text_frame.paragraphs[0]
        run = p.runs[0] if p.runs else p.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(32)
        font.bold = True
        font.color.rgb = RGBColor(68, 114, 196)
    
    def _style_content_text(self, text_frame) -> None:
        p = text_frame.paragraphs[0]
        run = p.runs[0] if p.runs else p.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(18)
        font.color.rgb = RGBColor(89, 89, 89)
    
    def _style_list_text(self, paragraph) -> None:
        run = paragraph.runs[0] if paragraph.runs else paragraph.add_run()
        font = run.font
        font.name = 'Calibri'
        font.size = Pt(20)
        font.color.rgb = RGBColor(68, 114, 196)
        paragraph.space_after = Pt(12)
    
    def _style_enhanced_content_text(self, text_frame) -> None:
        text_frame.word_wrap = True
        for paragraph in text_frame.paragraphs:
            paragraph.alignment = PP_ALIGN.LEFT
            for run in paragraph.runs:
                font = run.font
                font.name = 'Calibri'
                font.size = Pt(16)
                font.color.rgb = RGBColor(68, 68, 68)
            paragraph.space_after = Pt(8)
    
    def _sanitize_filename(self, filename: str) -> str:
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        return filename
    
    def generate_pptx(self, presentation: Presentation, filename: Optional[str] = None) -> str:
        if not filename:
            safe_title = self._sanitize_filename(presentation.title)
            filename = f"{safe_title}.pptx"
        
        if not filename.endswith('.pptx'):
            filename += '.pptx'
            
        output_path = self.output_dir / filename
        
        pptx = PPTXPresentation()
        
        total_slides = 1 + len(presentation.sections)
        for section in presentation.sections:
            total_slides += len(section.slides)
        
        slide_index = 0
        
        self._create_title_slide(pptx, presentation, slide_index, total_slides)
        slide_index += 1
        
        for section in presentation.sections:
            if len(section.slides) > 0:
                self._create_section_title_slide(pptx, section.title, slide_index, total_slides)
                slide_index += 1
                
                for slide in section.slides:
                    self._create_content_slide(pptx, slide.title, slide.content, slide_index, total_slides)
                    slide_index += 1
        
        pptx.save(str(output_path))
        return str(output_path.absolute())
    
    def list_presentations(self) -> list:
        return [f.name for f in self.output_dir.glob("*.pptx")]
    
    def delete_presentation(self, filename: str) -> bool:
        try:
            file_path = self.output_dir / filename
            if file_path.exists() and file_path.suffix == '.pptx':
                file_path.unlink()
                return True
        except Exception:
            pass
        return False
