import random
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR


class SlideDecorator:
    def __init__(self):
        self.decorations = {
            'shapes': [
                {'type': MSO_SHAPE.ROUNDED_RECTANGLE, 'color': RGBColor(230, 245, 255)},
                {'type': MSO_SHAPE.OVAL, 'color': RGBColor(255, 245, 230)},
                {'type': MSO_SHAPE.HEXAGON, 'color': RGBColor(245, 255, 230)},
                {'type': MSO_SHAPE.PENTAGON, 'color': RGBColor(255, 230, 245)},
                {'type': MSO_SHAPE.DIAMOND, 'color': RGBColor(240, 240, 255)},
            ],
            'accent_colors': [
                RGBColor(68, 114, 196),
                RGBColor(112, 173, 71),
                RGBColor(255, 192, 0),
                RGBColor(158, 72, 14),
                RGBColor(99, 99, 99),
                RGBColor(247, 150, 70),
            ],
            'background_colors': [
                RGBColor(248, 249, 250),
                RGBColor(245, 248, 250),
                RGBColor(250, 248, 245),
                RGBColor(248, 250, 245),
                RGBColor(250, 245, 248),
            ]
        }
    
    def add_slide_decoration(self, slide, slide_index: int, total_slides: int, slide_type: str = "content"):
        decoration_style = self._choose_decoration_style(slide_index, total_slides)
        
        if decoration_style == "accent_corner":
            self._add_corner_accent(slide)
        elif decoration_style == "side_shape":
            self._add_side_shape(slide)
        elif decoration_style == "background_shape":
            self._add_background_shape(slide)
        elif decoration_style == "border_accent":
            self._add_border_accent(slide)
        elif decoration_style == "minimal":
            self._add_minimal_accent(slide)
    
    def _choose_decoration_style(self, slide_index: int, total_slides: int) -> str:
        styles = ["accent_corner", "side_shape", "background_shape", "border_accent", "minimal"]
        
        if slide_index == 0:
            return "border_accent"
        elif slide_index == total_slides - 1:
            return "accent_corner"
        else:
            return random.choice(styles[:-1])
    
    def _add_corner_accent(self, slide):
        shape = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(8.5), Inches(0.2),
            Inches(1.3), Inches(0.8)
        )
        
        color = random.choice(self.decorations['accent_colors'])
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = color
        
        shape.line.fill.background()
    
    def _add_side_shape(self, slide):
        shapes_data = random.choice(self.decorations['shapes'])
        
        shape = slide.shapes.add_shape(
            shapes_data['type'],
            Inches(0.2), Inches(3),
            Inches(0.6), Inches(1.5)
        )
        
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = shapes_data['color']
        
        line = shape.line
        line.color.rgb = random.choice(self.decorations['accent_colors'])
        line.width = Pt(2)
    
    def _add_background_shape(self, slide):
        bg_color = random.choice(self.decorations['background_colors'])
        
        shape = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(0.3), Inches(6.5),
            Inches(9.4), Inches(1)
        )
        
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = bg_color
        
        line = shape.line
        line.color.rgb = RGBColor(220, 220, 220)
        line.width = Pt(1)
        
        shape.element.getparent().remove(shape.element)
        slide.shapes._spTree.insert(2, shape.element)
    
    def _add_border_accent(self, slide):
        left_border = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            Inches(0), Inches(0),
            Inches(0.1), Inches(7.5)
        )
        
        color = random.choice(self.decorations['accent_colors'])
        fill = left_border.fill
        fill.solid()
        fill.fore_color.rgb = color
        
        left_border.line.fill.background()
    
    def _add_minimal_accent(self, slide):
        color = random.choice(self.decorations['accent_colors'])
        
        accent_line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            Inches(0.5), Inches(1.3),
            Inches(3), Inches(0.05)
        )
        
        fill = accent_line.fill
        fill.solid()
        fill.fore_color.rgb = color
        
        accent_line.line.fill.background()
    
    def apply_text_formatting(self, text_frame, slide_type: str = "content"):
        if slide_type == "title":
            self._format_title_text(text_frame)
        elif slide_type == "content":
            self._format_content_text(text_frame)
        elif slide_type == "list":
            self._format_list_text(text_frame)
    
    def _format_title_text(self, text_frame):
        for paragraph in text_frame.paragraphs:
            for run in paragraph.runs:
                font = run.font
                if "важн" in run.text.lower() or "ключев" in run.text.lower():
                    font.color.rgb = random.choice(self.decorations['accent_colors'])
                    font.bold = True
    
    def _format_content_text(self, text_frame):
        text = text_frame.text
        
        if ":" in text:
            for paragraph in text_frame.paragraphs:
                if ":" in paragraph.text:
                    parts = paragraph.text.split(":")
                    if len(parts) >= 2:
                        paragraph.clear()
                        
                        title_run = paragraph.add_run()
                        title_run.text = parts[0] + ":"
                        title_run.font.bold = True
                        title_run.font.color.rgb = random.choice(self.decorations['accent_colors'])
                        
                        content_run = paragraph.add_run()
                        content_run.text = ":".join(parts[1:])
    
    def _format_list_text(self, text_frame):
        for paragraph in text_frame.paragraphs:
            if paragraph.text.strip().startswith(('•', '-', '1.', '2.', '3.')):
                for run in paragraph.runs:
                    if run.text.strip().startswith(('•', '-')):
                        run.font.color.rgb = random.choice(self.decorations['accent_colors'])
                        run.font.size = Pt(16)
