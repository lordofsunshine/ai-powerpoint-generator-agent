import json
import time
from typing import List, Optional
from g4f.client import Client
from ..models.presentation import Presentation, Section, Slide
from ..localization.manager import get_localization_manager


class AIService:
    def __init__(self, model: str = "gpt-4o-mini"):
        self.client = Client()
        self.model = model
        self.max_attempts = 3
        self.retry_delay = 1.0
        self.loc = get_localization_manager()
        
    def _make_request(self, prompt: str, temperature: float = 1.0) -> Optional[str]:
        for attempt in range(self.max_attempts):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=temperature
                )
                return response.choices[0].message.content.strip()
            except Exception as e:
                if attempt < self.max_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                raise e
        return None
    
    def _parse_json_response(self, response_text: str) -> Optional[dict]:
        try:
            cleaned_response = response_text.replace('\n', '').replace('\r', '')
            return json.loads(cleaned_response)
        except json.JSONDecodeError:
            try:
                start_idx = cleaned_response.find('{')
                end_idx = cleaned_response.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_part = cleaned_response[start_idx:end_idx]
                    return json.loads(json_part)
            except json.JSONDecodeError:
                pass
        return None
    
    def generate_section_titles(self, presentation_title: str, count: int, language: str = "русский") -> List[str]:
        prompt = self.loc.get_prompt(
            "section_titles",
            count=count,
            title=presentation_title
        )
        
        response = self._make_request(prompt, temperature=1.0)
        if not response:
            default_text = self.loc.t("section_default")
            return [f"{default_text} {i+1}" for i in range(count)]
            
        parsed = self._parse_json_response(response)
        if parsed and 'titles' in parsed:
            titles = parsed['titles']
            if isinstance(titles, list):
                return titles[:count]
            elif isinstance(titles, str):
                return [titles]
        
        default_text = self.loc.t("section_default")
        return [f"{default_text} {i+1}" for i in range(count)]
    
    def generate_slide_titles(self, section_title: str, presentation_title: str, count: int, language: str = "русский") -> List[str]:
        prompt = self.loc.get_prompt(
            "slide_titles",
            count=count,
            section_title=section_title,
            presentation_title=presentation_title
        )
        
        response = self._make_request(prompt, temperature=1.0)
        if not response:
            default_text = self.loc.t("slide_default")
            return [f"{default_text} {i+1}" for i in range(count)]
            
        parsed = self._parse_json_response(response)
        if parsed and 'titles' in parsed:
            titles = parsed['titles']
            if isinstance(titles, list):
                return titles[:count]
            elif isinstance(titles, str):
                return [titles]
        
        default_text = self.loc.t("slide_default")
        return [f"{default_text} {i+1}" for i in range(count)]
    
    def generate_slide_content(self, slide_title: str, section_title: str, language: str = "русский") -> str:
        prompt = self.loc.get_prompt(
            "slide_content",
            slide_title=slide_title,
            section_title=section_title
        )
        
        response = self._make_request(prompt, temperature=0.8)
        if not response:
            default_text = self.loc.t("slide_content_default")
            return f"{default_text} '{slide_title}'"
            
        parsed = self._parse_json_response(response)
        if parsed and 'content' in parsed:
            return parsed['content']
        
        default_text = self.loc.t("slide_content_default")
        return f"{default_text} '{slide_title}'"
    
    def generate_presentation_summary(self, presentation_title: str, language: str = "русский") -> str:
        prompt = self.loc.get_prompt(
            "presentation_summary",
            title=presentation_title
        )
        
        response = self._make_request(prompt, temperature=0.7)
        if not response:
            default_text = self.loc.t("presentation_topic")
            return f"{default_text} {presentation_title}"
            
        parsed = self._parse_json_response(response)
        if parsed and 'summary' in parsed:
            return parsed['summary']
        
        default_text = self.loc.t("presentation_topic")
        return f"{default_text} {presentation_title}"
