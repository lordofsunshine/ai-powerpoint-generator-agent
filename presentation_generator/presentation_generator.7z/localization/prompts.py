PROMPTS = {
    "русский": {
        "section_titles": """
        Ты часть системы генерации презентаций. Создай {count} заголовка секций для презентации на тему "{title}".
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "titles".
        Ключ "titles" содержит массив из {count} уникальных заголовков секций на русском языке.
        Каждый заголовок должен быть уникальным, но соответствовать общей теме презентации.
        Заголовки должны быть краткими (3-7 слов) и информативными.
        
        Пример ответа:
        {{"titles": ["Заголовок 1", "Заголовок 2", "Заголовок 3"]}}
        """,
        
        "slide_titles": """
        Ты часть системы генерации презентаций. Создай {count} заголовка слайдов для секции "{section_title}" 
        в презентации "{presentation_title}".
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "titles".
        Ключ "titles" содержит массив из {count} заголовков слайдов на русском языке.
        Заголовки должны логически развивать тему секции и быть связанными с общей темой презентации.
        Заголовки должны быть краткими (2-6 слов) и понятными.
        
        Пример ответа:
        {{"titles": ["Слайд 1", "Слайд 2", "Слайд 3"]}}
        """,
        
        "slide_content": """
        Ты часть системы генерации презентаций. Создай содержимое для слайда "{slide_title}" 
        в секции "{section_title}".
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "content".
        Ключ "content" содержит текст слайда на русском языке.
        
        КРИТИЧЕСКИ ВАЖНО:
        - НЕ используй markdown форматирование (**, *, _, # и т.д.)
        - НЕ оставляй пустые строки или незаполненные места
        - НЕ оставляй незавершенные предложения
        - НЕ пиши фразы типа "Содержимое для слайда" или "Здесь будет текст"
        - Содержимое должно быть ПОЛНЫМ и ЗАВЕРШЕННЫМ
        - Используй обычный текст без специальных символов форматирования
        - ОБЯЗАТЕЛЬНО заверши все предложения точкой
        
        Требования к содержимому:
        - Уникальное и точное содержание о реальной теме
        - Написано хорошим и подходящим языком  
        - Объем: 100-250 слов (ОБЯЗАТЕЛЬНО заполни весь объем ПОЛНЫМИ предложениями)
        - Информативное и полезное с КОНКРЕТНЫМИ деталями
        - Конкретные факты, цифры и примеры по теме
        - Структурированное (если нужны списки, используй простые маркеры • или цифры)
        - Полные предложения без сокращений и многоточий
        - НЕ используй фразы-заполнители или общие слова
        
        Пример ответа:
        {{"content": "Детальное содержимое слайда с конкретными примерами. Первый аспект темы включает важные характеристики и особенности. Второй момент раскрывает практическое применение с конкретными цифрами и фактами. Третий пункт демонстрирует результаты и выводы, которые можно сделать на основе представленной информации."}}
        """,
        
        "presentation_summary": """
        Создай краткое описание для презентации на тему "{title}".
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "summary".
        Описание должно быть на русском языке, кратким (1-2 предложения) и информативным.
        
        Пример ответа:
        {{"summary": "Краткое описание презентации..."}}
        """,
        
        "correct_title": """
        Пользователь просит изменить название презентации. Текущее название: "{current_title}"
        Запрос пользователя: "{user_request}"
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "title".
        Новое название должно быть на русском языке и соответствовать запросу пользователя.
        
        Пример ответа:
        {{"title": "Новое название презентации"}}
        """,
        
        "correct_content": """
        Пользователь просит изменить содержимое презентации. 
        Текущий слайд: "{slide_title}" с содержимым: "{slide_content}"
        Запрос пользователя: "{user_request}"
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "content".
        
        КРИТИЧЕСКИ ВАЖНО:
        - НЕ используй markdown форматирование (**, *, _, # и т.д.)
        - НЕ оставляй пустые строки или незаполненные места
        - Содержимое должно быть ПОЛНЫМ и ЗАВЕРШЕННЫМ
        - Используй обычный текст без специальных символов форматирования
        - Измененное содержимое должно быть на русском языке и учитывать запрос пользователя
        - Объем: 80-200 слов (ОБЯЗАТЕЛЬНО заполни весь объем)
        
        Пример ответа:
        {{"content": "Обновленное содержимое слайда с полным описанием и конкретными примерами"}}
        """,
        
        "correct_structure": """
        Пользователь просит изменить структуру презентации.
        Текущая структура:
        Презентация: "{presentation_title}"
        Секции: {sections_list}
        
        Запрос пользователя: "{user_request}"
        Отвечай только в JSON формате.
        Ответ должен содержать ключ "sections" с массивом новых названий секций на русском языке.
        
        Пример ответа:
        {{"sections": ["Новая секция 1", "Новая секция 2", "Новая секция 3"]}}
        """,
        
        "correct_style": """
        Пользователь просит изменить стиль содержимого презентации.
        Текущее содержимое слайда: "{slide_content}"
        Запрос пользователя: "{user_request}"
        Отвечай только в JSON формате.
        Ответ должен содержать только один ключ "content".
        
        КРИТИЧЕСКИ ВАЖНО:
        - НЕ используй markdown форматирование (**, *, _, # и т.д.)
        - НЕ оставляй пустые строки или незаполненные места
        - Содержимое должно быть ПОЛНЫМ и ЗАВЕРШЕННЫМ
        - Переформатируй содержимое согласно запросу пользователя на русском языке
        - Объем: 80-200 слов (ОБЯЗАТЕЛЬНО заполни весь объем)
        
        Пример ответа:
        {{"content": "Переформатированное содержимое в соответствии с запросом пользователя"}}
        """,
        
        "correct_general": """
        Пользователь просит внести изменения в презентацию.
        Презентация: "{presentation_title}"
        Описание: "{presentation_summary}"
        
        Запрос пользователя: "{user_request}"
        
        Проанализируй запрос и примени необходимые изменения к презентации.
        Отвечай только в JSON формате.
        Ответ должен содержать ключи: "title", "summary".
        Все изменения должны быть на русском языке.
        
        Пример ответа:
        {{"title": "Обновленное название", "summary": "Обновленное описание"}}
        """
    },
    
    "english": {
        "section_titles": """
        You are part of a presentation generation system. Create {count} section titles for a presentation on "{title}".
        Respond only in JSON format.
        Your response should contain only one key "titles".
        The "titles" key contains an array of {count} unique section titles in English.
        Each title should be unique but relevant to the overall presentation theme.
        Titles should be concise (3-7 words) and informative.
        
        Example response:
        {{"titles": ["Title 1", "Title 2", "Title 3"]}}
        """,
        
        "slide_titles": """
        You are part of a presentation generation system. Create {count} slide titles for section "{section_title}" 
        in presentation "{presentation_title}".
        Respond only in JSON format.
        Your response should contain only one key "titles".
        The "titles" key contains an array of {count} slide titles in English.
        Titles should logically develop the section theme and be related to the overall presentation topic.
        Titles should be concise (2-6 words) and clear.
        
        Example response:
        {{"titles": ["Slide 1", "Slide 2", "Slide 3"]}}
        """,
        
        "slide_content": """
        You are part of a presentation generation system. Create content for slide "{slide_title}" 
        in section "{section_title}".
        Respond only in JSON format.
        Your response should contain only one key "content".
        The "content" key contains the slide text in English.
        
        CRITICAL REQUIREMENTS:
        - DO NOT use markdown formatting (**, *, _, # etc.)
        - DO NOT leave empty lines or unfilled spaces
        - DO NOT leave unfinished sentences
        - DO NOT write phrases like "Content for slide" or "Text will be here"
        - Content must be COMPLETE and FINISHED
        - Use plain text without special formatting symbols
        - MUST end all sentences with proper punctuation
        
        Content requirements:
        - Unique and accurate content about the real topic
        - Written in good and appropriate language
        - Length: 100-250 words (MUST fill the entire volume with COMPLETE sentences)
        - Informative and useful with SPECIFIC details
        - Specific facts, numbers and examples about the topic
        - Structured (if lists needed, use simple bullets • or numbers)
        - Complete sentences without abbreviations or ellipsis
        - DO NOT use filler phrases or generic words
        
        Example response:
        {{"content": "Detailed slide content with specific examples. First aspect of the topic includes important characteristics and features. Second point reveals practical application with specific numbers and facts. Third item demonstrates results and conclusions that can be drawn from the presented information."}}
        """,
        
        "presentation_summary": """
        Create a brief description for a presentation on "{title}".
        Respond only in JSON format.
        Your response should contain only one key "summary".
        The description should be in English, brief (1-2 sentences) and informative.
        
        Example response:
        {{"summary": "Brief presentation description..."}}
        """,
        
        "correct_title": """
        User requests to change the presentation title. Current title: "{current_title}"
        User request: "{user_request}"
        Respond only in JSON format.
        Your response should contain only one key "title".
        New title should be in English and match the user's request.
        
        Example response:
        {{"title": "New presentation title"}}
        """,
        
        "correct_content": """
        User requests to change presentation content. 
        Current slide: "{slide_title}" with content: "{slide_content}"
        User request: "{user_request}"
        Respond only in JSON format.
        Your response should contain only one key "content".
        
        CRITICAL REQUIREMENTS:
        - DO NOT use markdown formatting (**, *, _, # etc.)
        - DO NOT leave empty lines or unfilled spaces
        - Content must be COMPLETE and FINISHED
        - Use plain text without special formatting symbols
        - Modified content should be in English and consider user's request
        - Length: 80-200 words (MUST fill the entire volume)
        
        Example response:
        {{"content": "Updated slide content with full description and specific examples"}}
        """,
        
        "correct_structure": """
        User requests to change presentation structure.
        Current structure:
        Presentation: "{presentation_title}"
        Sections: {sections_list}
        
        User request: "{user_request}"
        Respond only in JSON format.
        Your response should contain "sections" key with array of new section titles in English.
        
        Example response:
        {{"sections": ["New Section 1", "New Section 2", "New Section 3"]}}
        """,
        
        "correct_style": """
        User requests to change content style.
        Current slide content: "{slide_content}"
        User request: "{user_request}"
        Respond only in JSON format.
        Your response should contain only one key "content".
        
        CRITICAL REQUIREMENTS:
        - DO NOT use markdown formatting (**, *, _, # etc.)
        - DO NOT leave empty lines or unfilled spaces
        - Content must be COMPLETE and FINISHED
        - Reformat content according to user's request in English
        - Length: 80-200 words (MUST fill the entire volume)
        
        Example response:
        {{"content": "Reformatted content according to user's request"}}
        """,
        
        "correct_general": """
        User requests to make changes to the presentation.
        Presentation: "{presentation_title}"
        Description: "{presentation_summary}"
        
        User request: "{user_request}"
        
        Analyze the request and apply necessary changes to the presentation.
        Respond only in JSON format.
        Your response should contain keys: "title", "summary".
        All changes should be in English.
        
        Example response:
        {{"title": "Updated title", "summary": "Updated description"}}
        """
    }
}
